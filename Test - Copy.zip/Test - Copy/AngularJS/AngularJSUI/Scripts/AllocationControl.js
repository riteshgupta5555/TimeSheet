﻿/// <reference path="Scripts/angular.js" />
/// <reference path="Scripts/jquery-1.10.2.js" />
/// <reference path="Content/moment.min.js" />
//http://localhost:49790/api/GetProjectAllocation
//http://localhost:49790/PETWebAPI/api/GetProjectAllocation
var AllocationCtrl = function ($scope, $http) {
    debugger;
    $scope.dashboardCall = function () {

        // Load the Visualization API and the controls package.
        google.charts.load('current', { 'packages': ['controls', 'timeline'] });
        //google.load("visualization", "1.1", { packages: ["timeline", "controls"] });
        google.charts.setOnLoadCallback(drawDashboard);
        

        function drawDashboard() {
            //debugger;
            var dashboard = new google.visualization.Dashboard(document.getElementById('dashboard_div'));
            var dataTable = new google.visualization.DataTable();
            $.ajax({
                url: "http://localhost:50027/api/ProjectAllocation",
                dataType: "json",
                data: { _userId: 'sagard@positiveedge.net' },
                success: function (jsonData) {
                    //debugger;
                    $scope.TableData = jsonData.data;
                    dataTable.addColumn({ type: 'string', id: 'ProjectName', });
                    dataTable.addColumn({ type: 'string', id: 'dummy bar label' });
                    dataTable.addColumn({ 'type': 'string', 'role': 'tooltip', 'p': { 'html': true } })
                    dataTable.addColumn({ type: 'date', id: 'StartDate', label: 'StartDate' });
                    dataTable.addColumn({ type: 'date', id: 'EndDate', label: 'EndDate' });

                    for (var i = 0; i < jsonData.length; i++) {

                        var startDate = new Date(jsonData[i].MyStartDate);
                        var dtStart = new Date(startDate).getDate() + "";
                        var mnStart = new Date(startDate).getMonth() + 1 + "";
                        var yrStart = new Date(startDate).getFullYear() + 1;
                        var createStartDate = new Date(yrStart + "/" + mnStart + "/" + dtStart);
                        var momentStartDate = moment(createStartDate).format('L');

                        var endDate = new Date(jsonData[i].MyEndDate);
                        var dtEnd = new Date(endDate).getDate() + "";
                        var mnEnd = new Date(endDate).getMonth() + 1 + "";
                        var yrEnd = new Date(endDate).getFullYear() + 1 + "";
                        var createEndDate = new Date(yrEnd + "/" + mnEnd + "/" + dtEnd);
                        var momentEndDate = moment(createEndDate).format('L');

                        var toolTipCustom = createCustomToolTip(jsonData[i].ProjectName, momentStartDate, momentEndDate, jsonData[i].ProjectStartDate, jsonData[i].ProjectEndDate, jsonData[i].AllocationPercentage);

                        dataTable.addRow([jsonData[i].ProjectName, null, toolTipCustom, createStartDate, createEndDate]);
                    }
                }
            }).done(function () {
                var projectDateRangeSlider1 = new google.visualization.ControlWrapper({
                    'controlType': 'DateRangeFilter',
                    'containerId': 'filter_div1',
                    'options': {
                        //'filterColumnLabel': 'StartDate'
                        'filterColumnIndex': 3
                    }
                });

                var projectDateRangeSlider2 = new google.visualization.ControlWrapper({
                    'controlType': 'DateRangeFilter',
                    'containerId': 'filter_div2',
                    'options': {
                        //'filterColumnLabel': 'EndDate'
                        'filterColumnIndex': 4
                    }
                });

                var timelineChart = new google.visualization.ChartWrapper({
                    'chartType': 'Timeline',
                    'containerId': 'chart_div',
                    'options': {
                        'height': '600',
                        //'title': 'My Allocations',
                        'legend': 'none',
                        'timeline': {
                            'singleColor': '#8d8'
                        },
                        //'backgroundColor': 'transparent',
                        //'is3D': true,
                        'vAxis': {
                            gridlines: {
                                color: 'transparent'
                            }
                        }
                    },

                });

                var options = {
                    title: 'Project Allocations',
                    tooltip: { isHtml: true },
                    hAxis: {
                        title: "Dates",
                        format: 'MMM-yyyy'
                    },
                    vAxis: {
                        gridlines: {
                            color: 'transparent'
                        }
                    }
                    //backgroundColor: '#E4E4E4',
                    //chartArea: {
                    //    width: '70%'
                    //},
                    //timeline: {
                    //    singleColor: '#8d8'
                    //}
                };

                var view = new google.visualization.DataView(dataTable);
                view.setColumns([0, 1, 2, 3, 4]);

                dashboard.bind([projectDateRangeSlider1], [projectDateRangeSlider2]);
                dashboard.bind([projectDateRangeSlider2], [timelineChart]);
                dashboard.draw(view, options);
            });
        }
    }
};

function createCustomToolTip(prjName, myStartDate, myEndDate, prjStartDate, prjEndDate, allocation) {

    return (
        '<table id="tblToolTip">' +
        '<thead><tr><td>' + 'Project Name : ' + prjName + '</td></tr></thead>' +
        '<tbody><tr><td>' + 'My Start Date : ' + myStartDate + '</td></tr>' +
        '<tr><td>' + 'My End Date : ' + myEndDate + '</td></tr>' +
        '<tr><td>' + 'Project Start Date : ' + prjStartDate + '</td></tr>' +
        '<tr><td>' + 'Project End Date : ' + prjEndDate + '</td></tr>' +
        '<tr><td>' + 'Allocation : ' + allocation + '%' + '</td></tr>' +
        //'<tr><td>' + 'Project Manager : ' + prjManager + '</td></tr>' +
        '</tbody></table>' +
        '</div>'
        );
}

//var TableCtrl = function ($scope, $http) {
//    debugger;
//    $scope.tableCall = function () {
//        $http({
//            url: "http://localhost:49790/api/ProjectAllocation",
//            dataType: 'json',
//            method: 'GET',
//            data: '',
//            headers: {
//                "Content-Type": "application/json"
//            }
//        }).then(function (response) {
//            $scope.TableData = response.data;

//        }).error(function (error) {
//            alert("error");
//        });
//    }
//}

//function drawChart() {
//    $.ajax({
//        url: "list",
//        dataType: "json",
//        success: function (jsonData) {
//            var data = new google.visualization.DataTable();
//            // assumes "word" is a string and "count" is a number
//            data.addColumn('string', 'word');
//            data.addColumn('number', 'count');

//            for (var i = 0; i < jsonData.length; i++) {
//                data.addRow([jsonData[i].word, jsonData[i].count]);
//            }

//            var options = {
//                title: 'Certificate details',
//                is3D: true
//            };
//            var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
//            chart.draw(data, options);
//        }
//    });
//}