﻿/// <reference path="angular.min.js" />
/// <reference path="Scripts/jquery-1.10.2.js" />
/// <reference path="Content/moment.min.js" />
//http://localhost:49790/api/GetProjectAllocation
//http://localhost:49790/PETWebAPI/api/GetProjectAllocation

var app = angular
    .module("myApp", ["ui.router","angularUtils.directives.dirPagination"])
    .config(function ($stateProvider,$urlMatcherFactoryProvider,$urlRouterProvider,$locationProvider) {
        $urlMatcherFactoryProvider.caseInsensitive(true);

        //$urlRouterProvider.otherwise("/Login");
        $urlRouterProvider.otherwise(function ($injector) {
            var $state = $injector.get('$state');
            return $state.go('Home');
        });
        $stateProvider
        .state("Utilization", {
            url:"/Utilization",
            templateUrl: "/Utilization.html",
            controller: "UtilizationChartCntrl"
        })
        .state("Contacts", {
            url:"/Contacts",
            templateUrl: "/Contacts.html",
            controller: "ContactsCtrl"
        })
        .state("Allocation", {
            url:"/Allocation",
            templateUrl: "/Allocation.html",
            controller: "AllocationCtrl"
        })
        .state("Login", {
            url:"/Login",
            templateUrl: "/Login.html",
            controller: "LoginCtrl"
        })
        $locationProvider.html5Mode(true);

    })
    .controller("UtilizationChartCntrl", function ($scope, $http) {
        $scope.Email = 'sagard@positiveedge.net';
        $scope.Year = $scope.Year | '2016';

        $scope.setngincludeMatrix = function () {
            var el = document.getElementById("divMatrix");
            el.setAttribute('ng-include', "'UtilizationMatrix.html'");
            compile(el);

        }

        function compile(element) {
            var el = angular.element(element);
            $scope = el.scope();
            $injector = el.injector();
            $injector.invoke(function ($compile) {
                $compile(el)($scope)
            })
        }

        $scope.getChartData = function () {
            $http({
                url: "http://localhost:50027/api/utilizationchart/" + $scope.Email + '/' + $scope.Year,
                dataType: 'json',
                method: 'GET',
                data: '',
                headers: {
                    "Content-Type": "application/json"
                }
            }).success(function (response) {
                $scope.ChartData = JSON.parse('[' + response + ']');


                $scope.parJson = function (json) {
                    return angular.fromJson(json);
                }

                var YearData = [{ name: '2012-2013', value: '2012' },
                    { name: '2013-2014', value: '2013' },
                    { name: '2014-2015', value: '2014' },
                    { name: '2015-2016', value: '2015' },
                    { name: '2016-2017', value: '2016' }];

                $scope.YearData = YearData;
                $scope.setngincludeMatrix();

            }).error(function (error) {
                alert("Error in WebAPI Call " + error);
            });
        }

        $scope.getChartData();


    })
    .controller("ContactsCtrl", function ($scope, $http) {

        $scope.ltgt = "<<";
        $scope.state = false;
        $scope.Show = false;

        $scope.toggleState = function () {
            $scope.state = !$scope.state;
            $scope.ltgt = $scope.state ? ">>" : "<<";
            var mygridView = angular.element(document.querySelector('#gridView'));
            var mysidePanel = angular.element(document.querySelector('#sidePanel'));
            if ($scope.ltgt === "<<") {
                mysidePanel.removeClass('col-md-1');
                mysidePanel.addClass('col-md-2');
                mygridView.removeClass('col-md-11');
                mygridView.addClass('col-md-10');
            }

            else {
                mysidePanel.removeClass('col-md-2');
                mysidePanel.addClass('col-md-1');
                mygridView.removeClass('col-md-10');
                mygridView.addClass('col-md-11');
            }
        };

        $http({
            url: "http://localhost:50027/api/Employee",
            dataType: 'json',
            method: 'GET',
            data: '',
            headers: {
                "Content-Type": "application/json"
            }
        }).success(function (response) {
            $scope.EmployeeList = response;


            $scope.sort = function (keyname) {
                $scope.sortKey = keyname; // set the sort key to the param passed
                $scope.reverse = !$scope.reverse; //if true make it false and vice versa
            }
        }).error(function (error) {
            alert("error");
        });

    })
    .controller("AllocationCtrl", function ($scope, $http) {

        $scope.dashboardCall = function () {

            // Load the Visualization API and the controls package.

            google.charts.load('current', { 'packages': ['controls', 'timeline'] });
            //google.load("visualization", "1.1", { packages: ["timeline", "controls"] });
            google.charts.setOnLoadCallback(drawDashboard);

            function drawDashboard() {
                //debugger;
                var dashboard = new google.visualization.Dashboard(document.getElementById('dashboard_div'));
                var dataTable = new google.visualization.DataTable();
                $.ajax({
                    url: "http://localhost:50027/api/ProjectAllocation",
                    dataType: "json",
                    data: { _userId: 'sagard@positiveedge.net' },
                    success: function (jsonData) {
                        //debugger;
                        $scope.TableData = jsonData.data;
                        dataTable.addColumn({ type: 'string', id: 'ProjectName', });
                        dataTable.addColumn({ type: 'string', id: 'dummy bar label' });
                        dataTable.addColumn({ 'type': 'string', 'role': 'tooltip', 'p': { 'html': true } })
                        dataTable.addColumn({ type: 'date', id: 'StartDate', label: 'StartDate' });
                        dataTable.addColumn({ type: 'date', id: 'EndDate', label: 'EndDate' });

                        for (var i = 0; i < jsonData.length; i++) {

                            var startDate = new Date(jsonData[i].MyStartDate);
                            var dtStart = new Date(startDate).getDate() + "";
                            var mnStart = new Date(startDate).getMonth() + 1 + "";
                            var yrStart = new Date(startDate).getFullYear() + 1;
                            var createStartDate = new Date(yrStart + "/" + mnStart + "/" + dtStart);
                            var momentStartDate = moment(createStartDate).format('L');

                            var endDate = new Date(jsonData[i].MyEndDate);
                            var dtEnd = new Date(endDate).getDate() + "";
                            var mnEnd = new Date(endDate).getMonth() + 1 + "";
                            var yrEnd = new Date(endDate).getFullYear() + 1 + "";
                            var createEndDate = new Date(yrEnd + "/" + mnEnd + "/" + dtEnd);
                            var momentEndDate = moment(createEndDate).format('L');

                            var toolTipCustom = createCustomToolTip(jsonData[i].ProjectName, momentStartDate, momentEndDate, jsonData[i].ProjectStartDate, jsonData[i].ProjectEndDate, jsonData[i].AllocationPercentage);

                            dataTable.addRow([jsonData[i].ProjectName, null, toolTipCustom, createStartDate, createEndDate]);
                        }
                    }
                }).done(function () {
                    var projectDateRangeSlider1 = new google.visualization.ControlWrapper({
                        'controlType': 'DateRangeFilter',
                        'containerId': 'filter_div1',
                        'options': {
                            //'filterColumnLabel': 'StartDate'
                            'filterColumnIndex': 3
                        }
                    });

                    var projectDateRangeSlider2 = new google.visualization.ControlWrapper({
                        'controlType': 'DateRangeFilter',
                        'containerId': 'filter_div2',
                        'options': {
                            //'filterColumnLabel': 'EndDate'
                            'filterColumnIndex': 4
                        }
                    });

                    var timelineChart = new google.visualization.ChartWrapper({
                        'chartType': 'Timeline',
                        'containerId': 'chart_div',
                        'options': {
                            'height': '600',
                            //'title': 'My Allocations',
                            'legend': 'none',
                            'timeline': {
                                'singleColor': '#8d8'
                            },
                            //'backgroundColor': 'transparent',
                            //'is3D': true,
                            'vAxis': {
                                gridlines: {
                                    color: 'transparent'
                                }
                            }
                        },

                    });

                    var options = {
                        title: 'Project Allocations',
                        tooltip: { isHtml: true },
                        hAxis: {
                            title: "Dates",
                            format: 'MMM-yyyy'
                        },
                        vAxis: {
                            gridlines: {
                                color: 'transparent'
                            }
                        }
                        //backgroundColor: '#E4E4E4',
                        //chartArea: {
                        //    width: '70%'
                        //},
                        //timeline: {
                        //    singleColor: '#8d8'
                        //}
                    };

                    var view = new google.visualization.DataView(dataTable);
                    view.setColumns([0, 1, 2, 3, 4]);

                    dashboard.bind([projectDateRangeSlider1], [projectDateRangeSlider2]);
                    dashboard.bind([projectDateRangeSlider2], [timelineChart]);
                    dashboard.draw(view, options);
                });
            }
        }
    })
    .controller('LoginCtrl',function ($scope, $http, $window, $rootScope,names) {
    
        $scope.names = [];
        $scope.submit = function () {     
            $scope.dataLoading = true;

            var user = {
                username: $scope.username,
                password: $scope.password
            };
            var config = {
                headers: {
                    'Content-Type': 'application/json;charset=utf-8'
                }
            };
            names.add($scope.username);

            $http.post('http://localhost:50027/api/account/', user, config)
            .success(function (response) {
                if (response == true) {
                    $scope.name = user.username;
                    $window.location.href = '/Home.html';
                    //$window.location.href = 'http://localhost:50200/Project/Index';
                }
                else {
                    $window.location.href = '/Login.html';
                    $scope.error = "Invalid Login/Credentials";
                }
            });

        };
    })
    .controller('HomeCtrl', function ($scope, $http, names) {
        $scope.getnames = function () {
            $scope.names = names.get();
        }
        $scope.ltgt = "<<";
        $scope.state = false;
        $scope.Show = false;
        $scope.Application = false;
        //$scope.name = "RiteshG";
    
        $scope.toggleState = function () {
            $scope.state = !$scope.state;
            $scope.ltgt = $scope.state ? ">>" : "<<";
            var mygridView = angular.element(document.querySelector('#gridView'));
            var mysidePanel = angular.element(document.querySelector('#sidePanel'));
            if ($scope.ltgt === "<<") {
                mysidePanel.removeClass('col-md-1');
                mysidePanel.addClass('col-md-2');
                mygridView.removeClass('col-md-11');
                mygridView.addClass('col-md-10');
            }

            else {
                mysidePanel.removeClass('col-md-2');
                mysidePanel.addClass('col-md-1');
                mygridView.removeClass('col-md-10');
                mygridView.addClass('col-md-11');
            }
        };
    })
    .directive('sidebarDirective', function () {
        return {
            link: function (scope, element, attr) {
                scope.$watch(attr.sidebarDirective, function (newVal) {
                    if (newVal) {
                        element.removeClass('show');
                        return;
                    }
                    element.addClass('show');
                });
            }
        };
    })  
    .factory('names', function(){
        var names = {};

        names.list = [];

        names.add = function(message){
            names.list.push({message});
        };
  
        names.get = function(){
            return names.list;
        };

        return names;
    })
    .run(function ($rootScope, $http, $state, $templateCache) {
        //state change start
        $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
            // redirect to login page if not logged in and trying to access a restricted page   
            // console.info('fromState', fromState);
            //console.info('toState', toState);
            var loggedIn = $rootScope.currentUser;
            if (toState.authRequired) {              
                $rootScope.returnToState = {};
                $rootScope.returnToStateParams = {};
                if (!loggedIn) {
                    $rootScope.returnToState = toState;
                    $rootScope.returnToStateParams = toParams;

                    if (toState.name != "Login") {
                        event.preventDefault();
                        $state.go("Login");
                        return;
                    }
                }
            }
        });
    });
    
function createCustomToolTip(prjName, myStartDate, myEndDate, prjStartDate, prjEndDate, allocation) {

    return (
        '<table id="tblToolTip">' +
        '<thead><tr><td>' + 'Project Name : ' + prjName + '</td></tr></thead>' +
        '<tbody><tr><td>' + 'My Start Date : ' + myStartDate + '</td></tr>' +
        '<tr><td>' + 'My End Date : ' + myEndDate + '</td></tr>' +
        '<tr><td>' + 'Project Start Date : ' + prjStartDate + '</td></tr>' +
        '<tr><td>' + 'Project End Date : ' + prjEndDate + '</td></tr>' +
        '<tr><td>' + 'Allocation : ' + allocation + '%' + '</td></tr>' +
        //'<tr><td>' + 'Project Manager : ' + prjManager + '</td></tr>' +
        '</tbody></table>' +
        '</div>'
        );
}