﻿/// <reference path="angular.js" />


var app = angular.module("myApp", [])
.controller('HomeCtrl', function ($scope, $http) {
  
    

});







