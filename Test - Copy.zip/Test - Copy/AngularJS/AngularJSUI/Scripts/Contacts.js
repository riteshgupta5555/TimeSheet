﻿/// <reference path="angular.min.js" />
(function () {
    var app = angular.module('myApp', ['angularUtils.directives.dirPagination']);
    app.controller('ContactsCtrl', function ($scope, $http) {
        $http({
            url: "http://localhost:50027/api/Employee",
            dataType: 'json',
            method: 'GET',
            data: '',
            headers: {
                "Content-Type": "application/json"
            }
        }).success(function (response) {
            $scope.EmployeeList = response;
            $scope.sort = function (keyname) {
                $scope.sortKey = keyname; // set the sort key to the param passed
                $scope.reverse = !$scope.reverse; //if true make it false and vice versa
            }
            $scope.ltgt = ">>";
            $scope.state = false;
            $scope.toggleState = function () {
                $scope.state = !$scope.state;
                $scope.ltgt = $scope.state ? "<<" : ">>";
            };
            //$scope.contactsGrid = function () {
            //    var el = document.getElementById("grid");
            //    el.setAttribute('ng-include', "'Contacts.html'");
            //    compile(el);
            //}
            //function compile(element) {
            //    var el = angular.element(element);
            //    $scope = el.scope();
            //    $injector = el.injector();
            //    $injector.invoke(function ($compile) {
            //        $compile(el)($scope)
            //    })
            //}
        }).error(function (error) {
            alert("error");
        });

    });
    app.directive('sidebarDirective', function () {
        return {
            link: function (scope, element, attr) {
                scope.$watch(attr.sidebarDirective, function (newVal) {
                    if (newVal) {
                        element.addClass('show');
                        return;
                    }
                    element.removeClass('show');
                });
            }
        };
    });
}())