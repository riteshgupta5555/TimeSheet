﻿/// <reference path="Scripts/angular.js" />

(function () {
    'use strict';

angular
.module('myApp', ["ngRoute", "ngCookies"])
.config(function config($routeProvider, $locationProvider) {
    $routeProvider
        .when('/Login', {
            controller: 'LoginCtrl',
            templateUrl: 'Login.html',
            controllerAs: 'vm'
        })

    $locationProvider.html5Mode(true);
})
.controller('LoginCtrl', function ($scope, $http, $window, $rootScope) {           
    $scope.submit = function () {
        $scope.vm.dataLoading = true;
        var user = {
            username: $scope.vm.username,
            password: $scope.vm.password
        };
        var config = {
            headers: {
                'Content-Type': 'application/json;charset=utf-8'
            }
        };

       
        $http.post('http://localhost:50027/api/account/', user, config)
        .success(function (response) {
            if (response == true) {
                $rootScope.user = user.username;
                $window.location.href = '/Home.html';
                //$window.location.href = 'http://localhost:50200/Project/Index';
            }
            else {
                $window.location.href = '/Login.html';
                $scope.error = "Invalid Login/Credentials";
            }
        });
                
    };
})
.run(function run($rootScope, $location, $cookieStore, $http) {
    // keep user logged in after page refresh
    $rootScope.globals = $cookieStore.get('globals') || {};
    if ($rootScope.globals.currentUser) {
        $http.defaults.headers.common['Authorization'] = 'Basic ' + $rootScope.globals.currentUser.authdata; // jshint ignore:line
    }

    $rootScope.$on('$locationChangeStart', function (event, next, current) {
        // redirect to login page if not logged in and trying to access a restricted page
        var restrictedPage = $.inArray($location.path(), ['/Login']) === -1;
        var loggedIn = $rootScope.globals.currentUser;
        if (restrictedPage && !loggedIn) {
            $location.path('/Login');
        }
    });
})

})();