﻿var UtilizationChartcntrl = function ($scope, $http) {
    $scope.Email = 'sagard@positiveedge.net';
    $scope.Year =  $scope.Year | '2016';

    $scope.setngincludeMatrix = function () {
         var el = document.getElementById("divMatrix");
        el.setAttribute('ng-include', "'UtilizationMatrix.html'");
        compile(el);
       
    }
   
    function compile(element) {
        var el = angular.element(element);
        $scope = el.scope();
        $injector = el.injector();
        $injector.invoke(function ($compile) {
            $compile(el)($scope)
        })
    }
    
    $scope.getChartData = function () {
        $http({
            url: "http://localhost:50027/api/utilizationchart/" + $scope.Email +'/' + $scope.Year,
            dataType: 'json',
            method: 'GET',
            data:'',
            headers: {
                "Content-Type": "application/json"
            }
        }).success(function (response) {
            $scope.ChartData = JSON.parse('[' + response + ']');

          
               $scope.parJson = function (json) {
                return angular.fromJson(json);
            }

               var YearData = [{ name: '2012-2013', value: '2012' },
                   { name: '2013-2014', value: '2013' },
                   { name: '2014-2015', value: '2014'},
                   { name: '2015-2016', value: '2015'},
                   { name: '2016-2017', value: '2016' }];

               $scope.YearData = YearData;
               $scope.setngincludeMatrix();
            
        }).error(function (error) {
            alert("Error in WebAPI Call " + error);
        });
    }

    $scope.getChartData();

   
}