﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web.Mvc;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Security;
using TimeSheetServer.Models;


namespace TimeSheetServer.Controllers
{
    public class AccountController : ApiController
    {
        // GET api/account
        [System.Web.Http.HttpGet]
        public LoginModel Get()
        {
            LoginModel obj = new LoginModel();
           
            return obj;
            
        }

        // GET api/account/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/account
        //[Route("api/account/{userName}/{Password}")]
        //[HttpPost]
        public bool Post(LoginModel model)
        {
            //LoginModel model = new LoginModel();
            if (ModelState.IsValid)
            {
                string userName = model.UserName;
                string password = model.Password;
                if (Membership.ValidateUser(userName,password))
                {
                    FormsAuthentication.SetAuthCookie(userName, model.RememberMe);                   
                    return true;
                }
            }
            else
            {
                ModelState.AddModelError("CustomError", "The Username or password provided is incorrect");
                return false;
            }
            return false;
 
        }

        // PUT api/account/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/account/5
        public void Delete(int id)
        {
        }
    }

    public class LoginModel
    {
        [Required]
        [Display(Name = "User Name")]
        public string UserName { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [Display(Name = "Remember me?")]
        public bool RememberMe { get; set; }
    }
}
