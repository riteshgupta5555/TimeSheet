﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using TimeSheetServer.Models;


namespace TimeSheetServer.Controllers
{
    public class EmployeeController : ApiController
    {
        private PETTimeSheetConnection db = new PETTimeSheetConnection();

        // GET api/Employee
        //public IQueryable<UserProfile> GetUserProfiles()
        //{
        //    return db.UserProfiles;
            
        //}
        public List<ADProfile> GetUserProfiles()
        {
            List<ADProfile> li = TimeSheetServer.ADUserProfileProvider.Instance.Profiles;
            return li;
        }

        // GET api/Employee/5
        [ResponseType(typeof(UserProfile))]
        public IHttpActionResult GetUserProfile(string id)
        {
            UserProfile userprofile = db.UserProfiles.Find(id);
            if (userprofile == null)
            {
                return NotFound();
            }

            return Ok(userprofile);
        }

        // PUT api/Employee/5
        public IHttpActionResult PutUserProfile(string id, UserProfile userprofile)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != userprofile.EmailId)
            {
                return BadRequest();
            }

            db.Entry(userprofile).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserProfileExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST api/Employee
        [ResponseType(typeof(UserProfile))]
        public IHttpActionResult PostUserProfile(UserProfile userprofile)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.UserProfiles.Add(userprofile);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (UserProfileExists(userprofile.EmailId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = userprofile.EmailId }, userprofile);
        }

        // DELETE api/Employee/5
        [ResponseType(typeof(UserProfile))]
        public IHttpActionResult DeleteUserProfile(string id)
        {
            UserProfile userprofile = db.UserProfiles.Find(id);
            if (userprofile == null)
            {
                return NotFound();
            }

            db.UserProfiles.Remove(userprofile);
            db.SaveChanges();

            return Ok(userprofile);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool UserProfileExists(string id)
        {
            return db.UserProfiles.Count(e => e.EmailId == id) > 0;
        }

       
    }
}