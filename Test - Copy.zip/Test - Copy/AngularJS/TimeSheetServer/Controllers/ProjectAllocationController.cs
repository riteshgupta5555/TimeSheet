﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using TimeSheetServer.Models;

namespace TimeSheetServer.Controllers
{
    public class ProjectAllocationController : ApiController
    {
        private PETTimeSheetConnection db = new PETTimeSheetConnection();

        // GET api/ProjectAllocation
        public List<PPA> GetProjectPersonAllocations(string _userId)
        {
            PETTimeSheetConnection petTS = new PETTimeSheetConnection();

            List<PPA> listppa = new List<PPA>();

            var result = from ppAlloc in petTS.ProjectPersonAllocations
                         join ppProj in petTS.Projects
                         on ppAlloc.ProjectId equals ppProj.ProjectId
                         where ppAlloc.EmailId.Equals(_userId)
                         select new { ppProj.ProjectName, ppProj.ActualStartDate, ppProj.ActualEndDate, ppAlloc.StartDate, ppAlloc.EndDate, ppAlloc.AllocationPercentage };
            //"bhikshalum@positiveedge.net" //"bhikshalu@positiveedge.net"
            
            foreach (var dVar in result)
            {
                PPA ppAll = new PPA();
                ppAll.ProjectName = dVar.ProjectName;
                ppAll.MyStartDate = dVar.StartDate.ToString();
                ppAll.MyEndDate = dVar.EndDate.ToString();
                ppAll.ProjectStartDate = dVar.ActualStartDate.ToString();
                ppAll.ProjectEndDate = dVar.ActualEndDate.ToString();
                ppAll.AllocationPercentage = dVar.AllocationPercentage.ToString();
                //ppAll.ProjectManager = string.Empty;
                listppa.Add(ppAll);
            }
            return listppa;
        }

        
        // GET api/ProjectAllocation/5
        [ResponseType(typeof(ProjectPersonAllocation))]
        public IHttpActionResult GetProjectPersonAllocation(Guid id)
        {
            ProjectPersonAllocation projectpersonallocation = db.ProjectPersonAllocations.Find(id);
            if (projectpersonallocation == null)
            {
                return NotFound();
            }

            return Ok(projectpersonallocation);
        }

        // PUT api/ProjectAllocation/5
        public IHttpActionResult PutProjectPersonAllocation(Guid id, ProjectPersonAllocation projectpersonallocation)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != projectpersonallocation.ProjectPersonAllocationId)
            {
                return BadRequest();
            }

            db.Entry(projectpersonallocation).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ProjectPersonAllocationExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST api/ProjectAllocation
        [ResponseType(typeof(ProjectPersonAllocation))]
        public IHttpActionResult PostProjectPersonAllocation(ProjectPersonAllocation projectpersonallocation)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.ProjectPersonAllocations.Add(projectpersonallocation);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (ProjectPersonAllocationExists(projectpersonallocation.ProjectPersonAllocationId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = projectpersonallocation.ProjectPersonAllocationId }, projectpersonallocation);
        }

        // DELETE api/ProjectAllocation/5
        [ResponseType(typeof(ProjectPersonAllocation))]
        public IHttpActionResult DeleteProjectPersonAllocation(Guid id)
        {
            ProjectPersonAllocation projectpersonallocation = db.ProjectPersonAllocations.Find(id);
            if (projectpersonallocation == null)
            {
                return NotFound();
            }

            db.ProjectPersonAllocations.Remove(projectpersonallocation);
            db.SaveChanges();

            return Ok(projectpersonallocation);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool ProjectPersonAllocationExists(Guid id)
        {
            return db.ProjectPersonAllocations.Count(e => e.ProjectPersonAllocationId == id) > 0;
        }
    }
}