﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using TimeSheetServer.Models;
using Newtonsoft.Json;

namespace TimeSheetServer.Controllers
{
    public class UtilizationChartController : ApiController
    {
         TimesheetProvider provider = new TimesheetProvider();
         UtilizationChart datamatrix = new UtilizationChart();
        // GET api/utilizationchart

        [Route("api/utilizationchart/{Email}/{Year}")]
         public string Get(string Email, string Year)
        {
            try
            {

                string emailId = Email;// "sagard@positiveedge.net";
                decimal yearlyExpectedUtilization = 0;
                decimal.TryParse(Convert.ToString(ConfigurationManager.AppSettings["YearlyExpectedUtilization"]), out yearlyExpectedUtilization);
                bool isPastDataIncluded = Convert.ToString(ConfigurationManager.AppSettings["IncludePastDataForUtilization"]) == "YES";

               #region Calculate Start & End Date

                int startYear = Convert.ToInt32(Year);
                DateTime startDate;
                DateTime now = DateTime.Now;
                DateTime endDate = now;

                var dates = TimeSheetServer.Models.Utility.Instance.GetReportDuration((startYear == now.Year ? 0 : startYear), isTillDate: false);
                startDate = dates.Item1;
                endDate = dates.Item2;

                datamatrix = provider.GetMyUtilization(emailId, startDate, endDate, yearlyExpectedUtilization, isPastDataIncluded);

               var jsonData = JsonConvert.SerializeObject(datamatrix);
               return jsonData;
                
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }

        // GET api/utilizationchart/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/utilizationchart
        public void Post([FromBody]string value)
        {
        }

        // PUT api/utilizationchart/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/utilizationchart/5
        public void Delete(int id)
        {
        }

     
    }
}
               #endregion