﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using TimeSheetServer.Models;
using System.DirectoryServices;

namespace TimeSheetServer
{
    public sealed class ADUserProfileProvider
    {
        private PETTimeSheetConnection db = new PETTimeSheetConnection();
        /// <summary>
        /// Instance of the class
        /// </summary>
        private static ADUserProfileProvider instance;

        /// <summary>
        /// Gets instance of the class
        /// </summary>
        public static ADUserProfileProvider Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new ADUserProfileProvider();
                    return instance;
                }
                else
                {
                    return ADUserProfileProvider.instance;
                }
            }
        }

        public List<ADProfile> Profiles { get; private set; }

        private ADUserProfileProvider()
        {
            this.FillUserProfiles();
        }

        /// <summary>
        /// Retrieves the all AD Profiles 
        /// </summary>
        /// <returns>All AD Profiles</returns>
        public List<ADProfile> GetAllADProfiles()
        {
            List<ADProfile> allProfiles = new List<ADProfile>();

            var domainName = ConfigurationManager.AppSettings[Constant.AppSettingsKeyADDomainName];
            SearchResultCollection available = null;
            using (DirectoryEntry root = new DirectoryEntry(domainName))
            {
                using (DirectorySearcher searcher = new DirectorySearcher(root))
                {
                    available = searcher.FindAll();
                }
            }

            foreach (SearchResult src in available)
            {
                var profile = new ADProfile();
                profile.FirstName = src.Properties.Contains(Constant.ADKeyFirstName) && src.Properties[Constant.ADKeyFirstName][0] != null ? src.Properties[Constant.ADKeyFirstName][0].ToString() : string.Empty;
                profile.LastName = src.Properties.Contains(Constant.ADKeyLastName) && src.Properties[Constant.ADKeyLastName][0] != null ? src.Properties[Constant.ADKeyLastName][0].ToString() : string.Empty;
                profile.Email = src.Properties.Contains(Constant.ADKeyEmail) && src.Properties[Constant.ADKeyEmail][0] != null ? src.Properties[Constant.ADKeyEmail][0].ToString() : string.Empty;
                profile.FullyQualifiedDomainName = src.Path;
                profile.UserName = src.Properties.Contains(Constant.ADKeyUsername) && src.Properties[Constant.ADKeyUsername][0] != null ? src.Properties[Constant.ADKeyUsername][0].ToString() : string.Empty;
                profile.Phone = src.Properties.Contains(Constant.ADKeyPhone) && src.Properties[Constant.ADKeyPhone][0] != null ? src.Properties[Constant.ADKeyPhone][0].ToString() : string.Empty;
                profile.FullName = string.Format("{0} {1}", profile.FirstName, profile.LastName);
                if (profile.Email.Length > 0)
                {
                    allProfiles.Add(profile);
                }
            }

            return allProfiles;
        }

        /// <summary>
        /// Gets all available profiles in the AD and fills to Profiles
        /// </summary>
        private void FillUserProfiles()
        {
            List<ADProfile> profiles = new List<ADProfile>();
            List<ADProfile> profileList = new List<ADProfile>();

            var domainName = ConfigurationManager.AppSettings[Constant.AppSettingsKeyADDomainName];
            using (DirectoryEntry root = new DirectoryEntry(domainName))
            {
                using (DirectorySearcher searcher = new DirectorySearcher(root))
                {
                    searcher.SearchScope = SearchScope.Subtree;
                    searcher.Filter = "(objectClass=user)";

                    foreach (SearchResult result in searcher.FindAll())
                    {
                        if (result != null && result.Properties != null)
                        {
                            ADProfile profile = new ADProfile();
                            profile.FirstName = result.Properties.Contains(Constant.ADKeyFirstName) && result.Properties[Constant.ADKeyFirstName][0] != null ? result.Properties[Constant.ADKeyFirstName][0].ToString() : string.Empty;
                            profile.LastName = result.Properties.Contains(Constant.ADKeyLastName) && result.Properties[Constant.ADKeyLastName][0] != null ? result.Properties[Constant.ADKeyLastName][0].ToString() : string.Empty;
                            profile.Email = result.Properties.Contains(Constant.ADKeyEmail) && result.Properties[Constant.ADKeyEmail][0] != null ? result.Properties[Constant.ADKeyEmail][0].ToString().ToLowerInvariant() : string.Empty;
                            profile.UserName = result.Properties.Contains(Constant.ADKeyUsername) && result.Properties[Constant.ADKeyUsername][0] != null ? result.Properties[Constant.ADKeyUsername][0].ToString() : string.Empty;
                            profile.Phone = result.Properties.Contains(Constant.ADKeyPhone) && result.Properties[Constant.ADKeyPhone][0] != null ? result.Properties[Constant.ADKeyPhone][0].ToString() : string.Empty;
                            profile.FullName = string.Format("{0} {1}", profile.FirstName, profile.LastName);
                            profile.EmpId = 5;
                            if (profile.Email.Length > 0)
                            {
                                profiles.Add(profile);
                            }
                        }
                    }
                }
            }
            if (profiles.Count() > 0)
            {
                profileList = (from p in profiles
                               from u in db.UserProfiles.Where(row => row.EmailId.ToLower() == p.Email).DefaultIfEmpty()
                               select new ADProfile
                               {
                                   FirstName = p.FirstName,
                                   LastName = p.LastName,
                                   Email = p.Email,
                                   UserName = p.UserName,
                                   Phone = p.Phone,
                                   FullName = p.FullName,
                                   EmpId = u == null ? 0 : u.EmployeeId,
                                   DateOfJoining = u == null ? (DateTime?)null : u.DOJ.Value,
                               }).ToList();

                if (this.Profiles != null)
                {
                    this.Profiles.Clear();
                }

                this.Profiles = profileList;
            }




            
        }
    }
}