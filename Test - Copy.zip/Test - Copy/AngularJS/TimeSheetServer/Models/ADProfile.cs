﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TimeSheetServer.Models
{
    using System;
    using System.Collections.Generic;
    public class ADProfile
    {
         /// <summary>
        /// Gets or sets the EmpId of the User
        /// </summary>
        public int EmpId { get; set; }

        /// <summary>
        /// Gets or sets the First Name of the User
        /// </summary>
        public string FirstName
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the Last Name of the User
        /// </summary>
        public string LastName
        {
            get;
            set;
        }

        private string email = string.Empty;

        /// <summary>
        /// Gets or sets the Email Address of the AD User
        /// </summary>
        public string Email
        {
            get { return email.ToLower(); }
            set { email = value; }
        }



        /// <summary>
        /// Gets or sets the Phone number of the User
        /// </summary>
        public string Phone
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the Fully Qualified Domain Name (Path LDAP//UserDisplayname/CN=Name,OU=xx Users,DC=domain,DC=com)
        /// </summary>
        public string FullyQualifiedDomainName
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the username
        /// </summary>
        public string UserName
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or Sets the user's formatted firstname and lastname
        /// </summary>
        public string FullName
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets employee's date of joining
        /// </summary>
        public DateTime? DateOfJoining { get; set; }

        /// <summary>
        /// Gets or sets the Middle Name of the User
        /// </summary>
        public string MiddleName
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the Employee Status of the User
        /// </summary>
        public string EmployeeStatus
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the IsExclude of the User
        /// </summary>
        public bool IsExclude
        {
            get;
            set;
        }
    }
 }
