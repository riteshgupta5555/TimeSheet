﻿
namespace TimeSheetServer.Models
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;
   
    /// <summary>
    /// This provides all the operations on the resources
    /// </summary>
    public class TimesheetProvider : MarshalByRefObject, IDisposable
    {
        /// <summary>
        /// Instance of Database for CRUD operations.
        /// </summary>
        private PETTimeSheetConnection dataContext;

        public TimesheetProvider()
        {
            this.dataContext = new PETTimeSheetConnection();
           
        }

        /// <summary>
        /// This method returns list of holiday 
        /// </summary>
        /// <returns>Array of holiday</returns>
        public DateTime[] GetHolidayList()
        {
            List<DateTime> HolidayList;
            HolidayList = this.dataContext.Holidays.AsEnumerable().Where(row => row.EndDate == null && row.IsActive == true).Select(row => row.HolidayDate).ToList();

            var dateRangeHolidays = (from i in this.dataContext.Holidays.AsEnumerable()
                                     where i.EndDate != null && i.IsActive == true
                                     let start = i.HolidayDate
                                     let end = i.EndDate.Value
                                     select new
                                     {
                                         range = Enumerable.Range(0, 1 + end.Subtract(start).Days).Select(offset => start.AddDays(offset)).ToArray<DateTime>()
                                     }).ToList();

            if (dateRangeHolidays.Count > 0)
            {
                foreach (var array in dateRangeHolidays)
                {
                    HolidayList.AddRange(array.range);
                }
            }

            return HolidayList.ToArray();
        }


        /// <summary>
        /// Resource allocation to project(s) and approved timesheet list
        /// </summary>
        /// <param name="userEmail">Resource emailId</param>
        /// <param name="startDate">Start date</param>
        /// <param name="endDate">End date</param>
        /// <returns>List of TimesheetDataBE object</returns>
        public List<TimesheetProvider.TimesheetDataDB> GetResourceTimesheet(string userEmail, DateTime startDate, DateTime endDate)
        {
            int startWeekNo = Utility.Instance.GetWeekNo(startDate);
            int endWeekNo = Utility.Instance.GetWeekNo(endDate);
            int startYear = startDate.Year;
            int endYear = endDate.Year;
            userEmail = userEmail.ToLowerInvariant();
            string statusApp = "Approved";

            IEnumerable<TimesheetDataDB> result = from p in dataContext.Projects
                                                  join pt in this.dataContext.ProjectTimesheets on p.ProjectId equals pt.ProjectId
                                                  join wt in this.dataContext.WeeklyTimesheets on pt.WeeklyTimesheetId equals wt.WeeklyTimesheetId
                                                  join tc in this.dataContext.TimeCards on pt.ProjectTimesheetId equals tc.ProjectTimesheetId
                                                  join tsk in this.dataContext.Tasks on tc.TaskId equals tsk.TaskId
                                                  join tskg in this.dataContext.TaskGroups on tsk.TaskGroupId equals tskg.TaskGroupId
                                                  join orgc in this.dataContext.OrganizationCategories on tskg.CategoryId equals orgc.CategoryId
                                                  where
                                                  p.IsProductive && orgc.IsProductive
                                                  && tskg.IsProductive && wt.Status.Equals(statusApp)
                                                  && wt.EmailId.Equals(userEmail) && tc.Total > 0
                                                  select new TimesheetDataDB
                                                  {
                                                      ProjectProp = p,
                                                      CategoryProp = orgc,
                                                      TaskGroupProp = tskg,
                                                      TaskProp = tsk,
                                                      WeeklyTimesheetProp = wt,
                                                      ProjectTimesheetProp = pt,
                                                      TimeCardProp = tc
                                                  };

            result = from row in result
                     let wDate = this.GetDatesOfWeek(row.WeeklyTimesheetProp.Year, row.WeeklyTimesheetProp.WeekNo)
                     where wDate.Item1 >= startDate && wDate.Item2 <= endDate
                     select row;


            return result.ToList();

        }


        public UtilizationChart GetMyUtilization(string emailId, DateTime startDate, DateTime endDate, decimal expectedUtilization, bool isPastDataIncluded)
        {
            DateTime[] HolidayList;

            List<TimesheetProvider.TimesheetDataDB> lstTimesheet;
            IEnumerable<Tuple<int, decimal, decimal>> pastUtilizationList = null;
            using (TimesheetProvider provider = new TimesheetProvider())
            {
                lstTimesheet = provider.GetResourceTimesheet(emailId, startDate, endDate);
                HolidayList = new DateTime[0];

                if (isPastDataIncluded && startDate.Year == Utility.Instance.IncludePastDataUtilizationYear)
                {
                    pastUtilizationList = provider.GetPastUtilization(emailId);
                }
            }

            if (lstTimesheet.Count > 0)
            {
                int workingDays = this.GetBusinessDays(startDate, endDate, HolidayList);
                return this.GetUtilizationMatrix(lstTimesheet, workingDays, startDate, endDate, expectedUtilization, pastUtilizationList);
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// This method returns overall and monthly utilization matrix
        /// </summary>
        /// <param name="emailId">Email Id</param>
        /// <param name="timesheetList">List of Timesheet</param>
        /// <param name="startDate">Start date</param>
        /// <param name="endDate">End date</param>
        /// <param name="workingDays">Working days between start date and end date</param>
        /// <param name="expectedUtilization">Expected utilization percentage during an year</param>
        /// <returns>ArrayList</returns>
        private UtilizationChart GetUtilizationMatrix(List<TimesheetProvider.TimesheetDataDB> lstTimesheet, int workingDays, DateTime startDate, DateTime endDate, decimal expectedUtilization, IEnumerable<Tuple<int, decimal, decimal>> pastUtilizationList)
        {
            decimal[] matrix = new decimal[3];
            IEnumerable<Tuple<string, decimal, decimal, decimal>> monthlyUtilization = null;

            if (lstTimesheet != null && lstTimesheet.Count() > 0)
            {
                decimal nonProductiveHrs = workingDays * 8;
                decimal billableHrs = 0;
                decimal nonBillableHrs = 0;

                #region Utilization calculation

                List<TimesheetProvider.TimesheetDataDB> ProductiveList = lstTimesheet.Where(item => item.ProjectProp.IsProductive).ToList();
                if (ProductiveList != null && ProductiveList.Count() > 0)
                {
                    var projectTypeList = from pl in ProductiveList
                                          group pl by pl.ProjectProp.IsBillable into g
                                          let isBillable = g.Key
                                          select new { key = isBillable, blHrs = isBillable ? g.Sum(item => item.TimeCardProp.Total) : 0, nblHrs = isBillable ? 0 : g.Sum(item => item.TimeCardProp.Total), grp = isBillable ? g.ToList() : null };

                    if (projectTypeList != null)
                    {
                        var tempList = projectTypeList.Where(i => i.key).FirstOrDefault();
                        if (tempList != null)
                        {
                            nonBillableHrs = tempList.grp.Where(item => (!item.TaskProp.IsClientBillable)).Sum(row => row.TimeCardProp.Total);
                            billableHrs = tempList.blHrs - nonBillableHrs;
                        }

                        tempList = projectTypeList.Where(i => !i.key).FirstOrDefault();
                        if (tempList != null)
                        {
                            nonBillableHrs = tempList.nblHrs + nonBillableHrs;
                        }
                    }

                    List<MonthlyUtilization> monthlyUtilizationList = this.GetMonthlyUtilization(ProductiveList, startDate, endDate, workingDays, expectedUtilization, pastUtilizationList);
                    if (monthlyUtilizationList != null && monthlyUtilizationList.Count > 0)
                    {
                        monthlyUtilization = monthlyUtilizationList.Select(item => new Tuple<string, decimal, decimal, decimal>(string.Format("{0}-{1}", item.CurrentMonth.ToString(), item.Year), item.Expected, item.Actual, item.Result));
                    }
                }

                if (pastUtilizationList != null && pastUtilizationList.Count() > 0)
                {
                    billableHrs += pastUtilizationList.Sum(item => item.Item2);
                    nonBillableHrs += pastUtilizationList.Sum(item => item.Item3);
                }

                matrix[0] = billableHrs;
                matrix[1] = nonBillableHrs;

                decimal utilizedHrs = billableHrs + nonBillableHrs;
                nonProductiveHrs = utilizedHrs >= nonProductiveHrs ? 0 : (nonProductiveHrs - utilizedHrs);
                matrix[2] = nonProductiveHrs;

                #endregion

                #region Calculate hours in %

                matrix = matrix.Select(item => item > 0 ? decimal.Round((100 * item / (workingDays * 8)), 2, MidpointRounding.AwayFromZero) : item).ToArray();
                List<decimal[]> overallUtilization = new List<decimal[]>();
                decimal rangeValue = 0;

                for (int counter = 0; counter < matrix.Count(); counter++)
                {
                    rangeValue = matrix.Take(counter + 1).Sum();
                    overallUtilization.Add(new decimal[2] { rangeValue - matrix[counter], rangeValue });
                }
                overallUtilization[2][1] = 100;
                #endregion

                UtilizationChart chartLists = new UtilizationChart();
                chartLists.UtilizationMatrixData = new List<UtilizationMatrix>();
                chartLists.UtilizationGraphData = new List<UtilizationGraph>();
               
                ArrayList result = new ArrayList();
                result.Add(overallUtilization);
                result.Add(monthlyUtilization);

                for (int i = 0; i < monthlyUtilization.Count(); i++)
                {
                    UtilizationMatrix mu = new UtilizationMatrix();
                    mu.MonthYear = monthlyUtilization.ElementAt(i).Item1;
                    mu.Expected = monthlyUtilization.ElementAt(i).Item2;
                    mu.Actual = monthlyUtilization.ElementAt(i).Item3;
                    mu.Result = monthlyUtilization.ElementAt(i).Item4;
                    chartLists.UtilizationMatrixData.Add(mu);
                }

                for (int i = 0; i < overallUtilization.Count; i++)
                {
                    UtilizationGraph Ug = new UtilizationGraph();
                    Ug.start = overallUtilization[i][0];
                    Ug.End = overallUtilization[i][1];

                    chartLists.UtilizationGraphData.Add(Ug);
                }

                return chartLists;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Calculates number of business days, taking into account: 
        ///  - weekends (Saturdays and Sundays)
        ///  - bank holidays in the middle of the week
        /// </summary>
        /// <param name="firstDay">First day in the time interval</param>
        /// <param name="lastDay">Last day in the time interval</param>
        /// <param name="holidays">List of bank holidays excluding weekends</param>
        /// <returns>Number of business days during the time span</returns>
        private int GetBusinessDays(DateTime firstDay, DateTime lastDay, DateTime[] holidays)
        {
            firstDay = firstDay.Date;
            lastDay = lastDay.Date;
            if (firstDay > lastDay)
            {
                throw new ArgumentException("Incorrect last day " + lastDay);
            }

            DayOfWeek dayOfWeek = firstDay.DayOfWeek;

            TimeSpan span = lastDay - firstDay;
            int businessDays = span.Days + (dayOfWeek == DayOfWeek.Saturday || dayOfWeek == DayOfWeek.Sunday ? 0 : 1);

            int fullWeekCount = businessDays / 7;

            if (businessDays > fullWeekCount * 7)
            {
                int firstDayOfWeek = (int)firstDay.DayOfWeek;
                int lastDayOfWeek = (int)lastDay.DayOfWeek;
                if (lastDayOfWeek < firstDayOfWeek)
                {
                    lastDayOfWeek += 7;
                }

                if (firstDayOfWeek <= 6)
                {
                    if (lastDayOfWeek >= 7)
                    {
                        businessDays -= 2;
                    }
                    else if (lastDayOfWeek >= 6)
                    {
                        businessDays -= 1;
                    }
                }
                else if (firstDayOfWeek <= 7 && lastDayOfWeek >= 7)
                {
                    businessDays -= 1;
                }
            }

            // subtract the weekends during the full weeks in the interval
            businessDays -= fullWeekCount + fullWeekCount;

            // subtract the number of bank holidays during the time interval
            foreach (DateTime holiday in holidays)
            {
                DateTime bh = holiday.Date;
                if (firstDay <= bh && bh <= lastDay)
                {
                    --businessDays;
                }
            }

            return businessDays;
        }

        /// <summary>
        /// Returns utilization matrix from pre-calculated uilization data
        /// </summary>
        /// <param name="emailId">Email Id</param>
        /// <returns>Tuple collection</returns>
        public List<Tuple<int, decimal, decimal>> GetPastUtilization(string emailId)
        {
            List<Tuple<int, decimal, decimal>> result = (from u in this.dataContext.PastUtilizations.AsEnumerable()
                                                         where u.EmailId == emailId
                                                         select Tuple.Create(u.Month, u.BillableHrs, u.NonbillableHrs)).ToList();
            return result;
        }
        /// <summary>
        /// To dispose the dbContext.
        /// </summary>
        public void Dispose()
        {
            this.Dispose(true);
        }

        /// <summary>
        /// To dispose the native and unmanaged code.
        /// </summary>
        /// <param name="isnative"> to clear native and unmanaged</param>
        protected virtual void Dispose(bool isnative)
        {
            this.dataContext.Dispose();
           
        }

        /// <summary>
        /// This method retuns first & last day of a week
        /// </summary>
        /// <param name="year">Year of week</param>
        /// <param name="weekNumber">Week number</param>
        /// <returns>First & last date of the week</returns>
        public Tuple<DateTime, DateTime> GetDatesOfWeek(int year, int weekNumber)
        {
            System.Globalization.Calendar calendar = CultureInfo.CurrentCulture.Calendar;
            weekNumber = weekNumber - 1;
            DateTime firstOfYear = new DateTime(year, 1, 1, calendar);
            DateTime targetStDay = calendar.AddWeeks(firstOfYear, weekNumber);
            DateTime targetEdDay = calendar.AddWeeks(firstOfYear, weekNumber);

            DayOfWeek DayOfWeek = CultureInfo.CurrentCulture.DateTimeFormat.FirstDayOfWeek;

            while (targetStDay.DayOfWeek != DayOfWeek)
            {
                targetStDay = targetStDay.AddDays(-1);
            }

            DayOfWeek = DayOfWeek + 6;
            while (targetEdDay.Day != Convert.ToInt32(DayOfWeek))
            {
                targetEdDay = targetEdDay.AddDays(1);
            }
            return new Tuple<DateTime, DateTime>(targetStDay, targetEdDay);
        }

        /// <summary>
        /// This method returns monthly utilization
        /// </summary>
        /// <param name="timesheetList">List of Timesheet</param>
        /// <param name="startDate">Start date</param>
        /// <param name="endDate">End date</param>
        /// <param name="workingDays">Working days between start date and end date</param>
        /// <param name="expectedUtilization">Expected utilization percentage during an year</param>
        /// <returns>List of monthly utilization class object</returns>
        private List<MonthlyUtilization> GetMonthlyUtilization(List<TimesheetProvider.TimesheetDataDB> timesheetList, DateTime startDate, DateTime endDate, int workingDays, decimal expectedUtilization, IEnumerable<Tuple<int, decimal, decimal>> pastUtilizationList)
        {
            CultureInfo culture = CultureInfo.CurrentCulture;
            Month startingMonth = (Month)Enum.Parse(typeof(Month), startDate.Month.ToString());
            int yearlyTotalHrs = workingDays * 8;
            decimal monthlyExpectedUtilization = expectedUtilization > 0 ? expectedUtilization / 12 : 0;
            bool isPastDataEnabled = pastUtilizationList != null && pastUtilizationList.Count() > 0 ? true : false;

            List<MonthlyUtilization> monthlyMatrix = (from value in Enumerable.Range(0, (endDate.Year - startDate.Year) * 12 + (endDate.Month - startDate.Month + 1))
                                                      let sd = new DateTime(startDate.Year, startDate.Month, 1).AddMonths(value)
                                                      let ed = sd.AddMonths(1).AddDays(-1)
                                                      let sno = culture.Calendar.GetWeekOfYear(sd, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Sunday)
                                                      let eno = culture.Calendar.GetWeekOfYear(ed, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Sunday)
                                                      let weekRange = Enumerable.Range(sno, (eno - sno + 1)).ToArray()
                                                      select new MonthlyUtilization
                                                      {
                                                          CurrentMonth = (Month)sd.Month,
                                                          Year = sd.Year,
                                                          StartDate = sd,
                                                          EndDate = ed,
                                                          WeekRange = weekRange,
                                                          WeekStartDay = sd.DayOfWeek,
                                                          WeekEndDay = ed.DayOfWeek
                                                      }).ToList();

            //Get the sum of actual hours worked for each month
            if (monthlyMatrix != null && monthlyMatrix.Count > 0)
            {
                //Update monthly hours
                decimal adjustHours = 0;
                decimal utilizedPerc = 0;
                int currentIndex = 0;
                Tuple<int, decimal, decimal> pastdataItem = null;
                foreach (MonthlyUtilization item in monthlyMatrix)
                {
                    item.TotalHrs = timesheetList.Where(row => item.WeekRange.Contains(row.WeeklyTimesheetProp.WeekNo) && row.WeeklyTimesheetProp.Year == item.Year).Sum(tc => tc.TimeCardProp.Total);

                    //Add past utilization data
                    if (isPastDataEnabled)
                    {
                        pastdataItem = pastUtilizationList.Where(row => row.Item1 == (int)item.CurrentMonth).FirstOrDefault();
                        if (pastdataItem != null)
                        {
                            item.TotalHrs += pastdataItem.Item2 + pastdataItem.Item3;
                        }
                    }

                    #region Adjust Month Start
                    if (item.WeekStartDay != DayOfWeek.Sunday)
                    {
                        var timecardData = (from p in timesheetList
                                            where p.WeeklyTimesheetProp.WeekNo == item.WeekRange.First()
                                            group p.TimeCardProp by 1 into grp
                                            select new
                                            {
                                                day1 = grp.Sum(i => i.Day1),
                                                day2 = grp.Sum(i => i.Day2),
                                                day3 = grp.Sum(i => i.Day3),
                                                day4 = grp.Sum(i => i.Day4),
                                                day5 = grp.Sum(i => i.Day5),
                                                day6 = grp.Sum(i => i.Day6),
                                                day7 = grp.Sum(i => i.Day7),
                                            }).FirstOrDefault();


                        if (timecardData != null)
                        {
                            switch (item.WeekStartDay)
                            {
                                case DayOfWeek.Monday:
                                    adjustHours = timecardData.day1;
                                    break;
                                case DayOfWeek.Tuesday:
                                    adjustHours = timecardData.day1 + timecardData.day2;
                                    break;
                                case DayOfWeek.Wednesday:
                                    adjustHours = timecardData.day1 + timecardData.day2 + timecardData.day3;
                                    break;
                                case DayOfWeek.Thursday:
                                    adjustHours = timecardData.day1 + timecardData.day2 + timecardData.day3 + timecardData.day4;
                                    break;
                                case DayOfWeek.Friday:
                                    adjustHours = timecardData.day1 + timecardData.day2 + timecardData.day3 + timecardData.day4 + timecardData.day5;
                                    break;
                                case DayOfWeek.Saturday:
                                    adjustHours = timecardData.day1 + timecardData.day2 + timecardData.day3 + timecardData.day4 + timecardData.day5 + timecardData.day6;
                                    break;
                            }
                        }
                    }
                    #endregion

                    #region Adjust Month End
                    if (item.WeekEndDay != DayOfWeek.Saturday)
                    {
                        var timecardData = (from p in timesheetList
                                            where p.WeeklyTimesheetProp.WeekNo == item.WeekRange.Last()
                                            group p.TimeCardProp by 1 into grp
                                            select new
                                            {
                                                day1 = grp.Sum(i => i.Day1),
                                                day2 = grp.Sum(i => i.Day2),
                                                day3 = grp.Sum(i => i.Day3),
                                                day4 = grp.Sum(i => i.Day4),
                                                day5 = grp.Sum(i => i.Day5),
                                                day6 = grp.Sum(i => i.Day6),
                                                day7 = grp.Sum(i => i.Day7),
                                            }).FirstOrDefault();

                        if (timecardData != null)
                        {
                            switch (item.WeekEndDay)
                            {
                                case DayOfWeek.Sunday:
                                    adjustHours += timecardData.day1 + timecardData.day2 + timecardData.day3 + timecardData.day4 + timecardData.day5 + timecardData.day6 + timecardData.day7;
                                    break;
                                case DayOfWeek.Monday:
                                    adjustHours += timecardData.day3 + timecardData.day4 + timecardData.day5 + timecardData.day6 + timecardData.day7;
                                    break;
                                case DayOfWeek.Tuesday:
                                    adjustHours += timecardData.day4 + timecardData.day5 + timecardData.day6 + timecardData.day7;
                                    break;
                                case DayOfWeek.Wednesday:
                                    adjustHours += timecardData.day5 + timecardData.day6 + timecardData.day7;
                                    break;
                                case DayOfWeek.Thursday:
                                    adjustHours += timecardData.day6 + timecardData.day7;
                                    break;
                                case DayOfWeek.Friday:
                                    adjustHours += timecardData.day7;
                                    break;
                            }
                        }
                    }
                    #endregion

                    if (adjustHours > 0)
                    {
                        item.TotalHrs -= adjustHours;
                        adjustHours = 0;
                    }

                    currentIndex = monthlyMatrix.IndexOf(item);
                    item.Expected = item.CurrentMonth == startingMonth ? (decimal)monthlyExpectedUtilization : (decimal)monthlyExpectedUtilization * (currentIndex + 1);
                    if (item.TotalHrs > 0)
                    {
                        item.Actual = item.CurrentMonth == startingMonth ? (decimal)(item.TotalHrs * 100 / yearlyTotalHrs) : item.Actual += (decimal)monthlyMatrix[currentIndex - 1].Actual + (decimal)(item.TotalHrs * 100 / yearlyTotalHrs);
                        utilizedPerc = item.Actual;
                    }
                    item.Result = utilizedPerc - item.Expected;
                }
            }

            return monthlyMatrix;
        }


        #region Related Classes

        public class ProjectCreateDto
        {
            public Guid Id { get; set; }
            public string Name { get; set; }
            public string ProjectManager { get; set; }
            public string ProjectStartDate { get; set; }
            public string ProjectEndDate { get; set; }
            public string AllocationId { get; set; }
            public string AllocationStartDate { get; set; }
            public string AllocationEndDate { get; set; }
            public string AllocationPercent { get; set; }
            public object pt { get; set; }


        }

        public class Record
        {
            public string AllocationId { get; set; }
            public string AllocationStartDate { get; set; }
        }

        /// <summary>
        /// Timesheet data DB entities
        /// </summary>
        public class TimesheetDataDB
        {
            /// <summary>
            /// Gets or sets Project Entity
            /// </summary>
            public Project ProjectProp { get; set; }

            /// <summary>
            /// Gets or sets Timecard Entity
            /// </summary>
            public TimeCard TimeCardProp { get; set; }

            /// <summary>
            /// Gets or sets ProjectTimesheet Entity
            /// </summary>
            public ProjectTimesheet ProjectTimesheetProp { get; set; }

            /// <summary>
            /// Gets or sets WeeklyTimesheet Entity
            /// </summary>
            public WeeklyTimesheet WeeklyTimesheetProp { get; set; }


            /// <summary>
            /// Gets or sets ProjectPersonAllocation Entity
            /// </summary>
            public ProjectPersonAllocation ProjectPersonProp { get; set; }

            /// <summary>
            /// Gets or sets Task Entityr
            /// </summary>
            public Task TaskProp { get; set; }

            /// <summary>
            /// Gets or sets TaskGroup Entity
            /// </summary>
            public TaskGroup TaskGroupProp { get; set; }

            /// <summary>
            /// Gets or sets OrganizationCategory Entity
            /// </summary>
            public OrganizationCategory CategoryProp { get; set; }

        }

        public class MonthlyUtilization
        {
            private decimal expected;
            private decimal actual;
            private decimal result;

            public decimal TotalHrs { get; set; }
            public IEnumerable<int> WeekRange { get; set; }
            public Month CurrentMonth { get; set; }
            public int Year { get; set; }
            public DateTime StartDate { get; set; }
            public DateTime EndDate { get; set; }
            public DayOfWeek WeekStartDay { get; set; }
            public DayOfWeek WeekEndDay { get; set; }
            public decimal Expected { get { return decimal.Round(this.expected, 2, MidpointRounding.AwayFromZero); } set { this.expected = value; } }
            public decimal Actual { get { return decimal.Round(this.actual, 2, MidpointRounding.AwayFromZero); } set { this.actual = value; } }
            public decimal Result { get { return decimal.Round(this.result, 2, MidpointRounding.AwayFromZero); } set { this.result = value; } }
            public string  MonthYear { get; set; }
        }


        public class UtilizationGraph
        {
            public string Legend { get; set; }
            public decimal start { get; set; }
            public decimal End { get; set; }

        }

        public class UtilizationMatrix
        {
            private decimal expected;
            private decimal actual;
            private decimal result;
            public decimal Expected { get { return decimal.Round(this.expected, 2, MidpointRounding.AwayFromZero); } set { this.expected = value; } }
            public decimal Actual { get { return decimal.Round(this.actual, 2, MidpointRounding.AwayFromZero); } set { this.actual = value; } }
            public decimal Result { get { return decimal.Round(this.result, 2, MidpointRounding.AwayFromZero); } set { this.result = value; } }
            public string MonthYear { get; set; }
        }
    }
}
#endregion