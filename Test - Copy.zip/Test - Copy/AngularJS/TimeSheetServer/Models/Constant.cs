﻿// -----------------------------------------------------------------------
// <copyright file="Constant.cs" company="PositiveEdge">
// Copyright 2012 - 2015 PositiveEdge.
// </copyright>
// -----------------------------------------------------------------------

namespace TimeSheetServer.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// This class holds application level constants
    /// </summary>
    public class Constant
    {
        /// <summary>
        /// This constant provides date format 
        /// </summary>
        public const string DateFormat = "{0:M/d/yyyy}";

        /// <summary>
        /// This constant provides date format 
        /// </summary>
        public const string DateMonth = "{0:dd/MM/yyyy}";

        /// <summary>
        /// Date format DD/MM/YY
        /// </summary>
        public const string DDMMYY = "dd/MM/yy";

        /// <summary>
        /// Date format DD/MM/YYYY
        /// </summary>
        public const string DDMMYYYY = "dd/MM/yyyy";

         /// <summary>
        /// Date format DD/MM/YYYY
        /// </summary>
        public const string DATEDDMMYYYY = "ddMMyyyy";         

        /// <summary>
        /// Date format MMM/YY
        /// </summary>
        public const string MMMYY = "MMM-yy";

        /// <summary>
        /// Date format DD/MM/YYYY
        /// </summary>
        public const string HHAMPM = "hh:00 tt";

        /// <summary>
        /// Date format DD/MM/YYYY
        /// </summary>
        public const string FrenchFrance = "fr-FR";

        /// <summary>
        /// Represents the status NotFilled
        /// </summary>
        public const string NotFilled = "Not Filled";

        /// <summary>
        /// Represents the status NotAllocated
        /// </summary>
        public const string NotAllocated = "Not Allocated";

        /// <summary>
        /// Represents the column Resource Name
        /// </summary>
        public const string ResourceName = "Resource Name";

        /// <summary>
        /// Represents the column Resource Email
        /// </summary>
        public const string ResourceEmail = "Resource Email";

         /// <summary>
        /// Represents the column Weekly Timesheet Status
        /// </summary>
        public const string WeeklyTimesheetStatus = "Weekly Timesheet Status";

        /// <summary>
        /// AppSettings Key name for AD Domain Name
        /// </summary>
        internal const string AppSettingsKeyADDomainName = "ADDomain";

        /// <summary>
        /// AD Property name for Firstname
        /// </summary>
        internal const string ADKeyFirstName = "givenname";

        /// <summary>
        /// AD Property name for Lastname
        /// </summary>
        internal const string ADKeyLastName = "sn";

        /// <summary>
        /// AD Property name for Email
        /// </summary>
        internal const string ADKeyEmail = "mail";

        /// <summary>
        /// AD Property name for Username
        /// </summary>
        internal const string ADKeyUsername = "samaccountname";

        /// <summary>
        /// AD Property name for Telephone number
        /// </summary>
        internal const string ADKeyPhone = "telephonenumber";
        
    }
}
