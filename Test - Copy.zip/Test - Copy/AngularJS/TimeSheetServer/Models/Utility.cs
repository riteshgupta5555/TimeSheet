﻿// -----------------------------------------------------------------------
// <copyright file="Utility.cs" company="PositiveEdge">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

namespace TimeSheetServer.Models
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Globalization;
    using System.Linq;

    /// <summary>
    /// CRUD enum - Create, Read, Update, Delete
    /// </summary>
    public enum CRUDAction
    {
        /// <summary>
        /// For create action
        /// </summary>
        Create = 0,

        /// <summary>
        /// For read action 
        /// </summary>
        Read,

        /// <summary> 
        /// For update action
        /// </summary>
        Update,

        /// <summary>
        /// For delete action
        /// </summary>
        Delete
    }

    /// <summary>
    /// Provides enum for roles
    /// </summary>
    public enum UserRole
    {
        /// <summary>
        /// System Admin
        /// </summary>
        SystemAdmin,

        /// <summary>
        /// Project Manager
        /// </summary>
        ProjectManager,

        /// <summary>
        /// Project Approver
        /// </summary>
        ProjectApprover,

        /// <summary>
        /// Employee Role
        /// </summary>
        Employee,

        /// <summary>
        /// Authorised Approver
        /// </summary>
        AuthorisedApprover,

        /// <summary>
        /// Stakeholder Role
        /// </summary>
        StakeHolder
    }

    /// <summary>
    /// Represents roles.
    /// </summary>
    public enum RoleType
    {
        /// <summary>
        /// Represents role in the Organization
        /// </summary>
        Organization = 0,

        /// <summary>
        /// Represents role in the  Project
        /// </summary>
        System = 1
    }

    /// <summary>
    /// Dashboard Chart Enums
    /// </summary>
    public enum DashboardChart
    {
        /// <summary>
        /// Resource utilization chart
        /// </summary>
        Utilization,

        /// <summary>
        /// Resource utilization chart
        /// </summary>
        Allocation,

        /// <summary>
        /// Project Manager chart
        /// </summary>
        Manager,

        /// <summary>
        /// Resource utilization chart
        /// </summary>
        ResourceAllocation,
    }

    /// <summary>
    /// Month enumeration
    /// </summary>
    public enum Month : int
    {
        January = 1,
        February,
        March,
        April,
        May,
        June,
        July,
        August,
        September,
        October,
        November,
        December
    }

    /// <summary>
    /// This enum provides report type.
    /// </summary>
    public enum ReportDuration
    {
        /// <summary>
        /// From 1st April of current year to 31st March of next year
        /// </summary>
        FinancialYear,

        /// <summary>
        /// From 1st January of current year to 31st December of current year
        CurrentYear,

        /// <summary>
        /// User defined key value of customDates in web.config file in MM/YYYY format
        /// </summary>
        CustomDates,

        /// <summary>
        /// From 1st April of current year to till the date
        /// </summary>
        FincancialYearTillDate,

        /// <summary>
        /// From 1st January of current year to till the date
        /// </summary>
        CurrentYearTillDate
    }
    /// <summary>
    /// This enum provides Report List.
    /// </summary>
    public enum ReportList
    {
        DefaulterReport,
        ProjectPerformance,
        ProjectUtilizationReport,
        ResourceUtilization,
        ResourceUtilizationByProjectByCapacity,
        ResourceAllocationReport,
        TimeSheetReport_AA,
        TimeSheetReport_Employee,
        TimeSheetReport_Manager,
        TimeSheetReportMaster,
        TimeSheetReportMaster_AA,
        WarningReport
    }

    /// <summary>
    /// Email Template list
    /// </summary>
    public enum EmailTemplate
    {
        /// <summary>
        /// Timesheet Reminder
        /// </summary>
        TimesheetReminder,

        /// <summary>
        /// Timesheet Warning
        /// </summary>
        TimesheetWarning,

        /// <summary>
        /// Timesheet NonCompliance
        /// </summary>
        TimesheetNonCompliance,

        /// <summary>
        /// Timesheet Approver Reminder
        /// </summary>
        TimesheetApproverReminder,

        /// <summary>
        /// Timesheet Approver Warning
        /// </summary>
        TimesheetApproverWarning,

        /// <summary>
        /// Timesheet Approved Notification
        /// </summary>
        TimesheetApprovedNotification,

        /// <summary>
        /// Timesheet Rejected Notification
        /// </summary>
        TimesheetRejectedNotification,

        /// <summary>
        /// Project Ending Soon Alert
        /// </summary>
        ProjectEndingSoonAlert,

        /// <summary>
        /// Resource Allocation Ending Soon Alert
        /// </summary>
        ResourceAllocationEndingSoonAlert,

        /// <summary>
        /// Project Pendingfor Approval
        /// </summary>
        ProjectPendingforApproval,

        /// <summary>
        /// Project Creation Notification
        /// </summary>
        ProjectCreationNotification,

        /// <summary>
        /// Project Rejected Notification
        /// </summary>
        ProjectRejectedNotification,

        /// <summary>
        /// Project Approved Notification
        /// </summary>
        ProjectApprovedNotification,

        /// <summary>
        /// Project Resource Allocation Notification
        /// </summary>
        ProjectResourceAllocationNotification,

        /// <summary>
        /// Timesheet Approval Pending
        /// </summary>
        TimesheetApprovalPending,

        /// <summary>
        /// Timesheet Submission Pending
        /// </summary>
        TimesheetSubmissionPending,

        /// <summary>
        /// Timesheet LatelySubmitted Notification
        /// </summary>
        TimesheetLatelySubmittedNotification
    }

    /// <summary>
    /// UserProfile Enums
    /// </summary>
    public enum EmployeeStatus
    {
        /// <summary>
        /// Active Employees
        /// </summary>
        Active,

        /// <summary>
        /// Employees Left from Organization
        /// </summary>
        InActive,

        /// <summary>
        ///Onsite Employees 
        /// </summary>
        OnSite

       
    }

    /// <summary>
    /// Utility Class for Project level commom methods
    /// </summary>
    public class Utility
    {
        /// <summary>
        /// 
        /// </summary>
        private static readonly Utility instance = new Utility();

        public static Utility Instance
        {
            get
            {
                return instance;
            }
        }

        /// <summary>
        /// Gets Extended Days for Project End Date.
        /// </summary>
        /// <returns>No of Extended Days</returns>
        public int ExtendedEndDays
        {
            get
            {
                return int.Parse(ConfigurationManager.AppSettings.Get("ExtendedEndDays"));
            }
        }

        /// <summary>
        /// Gets Maximum Allowed Hours for non allocated project
        /// </summary>
        /// <returns></returns>
        public int ProjectMaxCapHours
        {
            get
            {
                return int.Parse(ConfigurationManager.AppSettings.Get("ProjectMaxCapHours"));
            }
        }

        /// <summary>
        /// Gets a value indicating whether to Include Sat and Sun for Resource Pool
        /// </summary>
        /// <returns></returns>
        public bool IncludeSatSunforRP
        {
            get
            {
                return Convert.ToBoolean(ConfigurationManager.AppSettings.Get("IncludeSatSunforRP"));
            }
        }

        /// <summary>
        /// Gets Project Creation maximum past allowed days
        /// </summary>
        /// <returns></returns>
        public int ProjectCreationAllowedDays
        {
            get
            {
                return int.Parse(ConfigurationManager.AppSettings.Get("ProjectCreationAllowedDays"));
            }
        }

        /// <summary>
        /// Gets Resource Pool  Project Name
        /// </summary>
        /// <returns></returns>
        public string RPProjectName
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("RPProjectName");
            }
        }

        /// <summary>
        /// Gets Resource Pool Task Group Name
        /// </summary>
        /// <returns></returns>
        public string RPTaskGroupName
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("RPTaskGroupName");
            }
        }

        /// <summary>
        /// Gets Resource Pool Task Name
        /// </summary>
        /// <returns></returns>
        public string RPTaskName
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("RPTaskName");
            }
        }

        /// <summary>
        /// Gets Resource Pool Task Name
        /// </summary>
        /// <returns></returns>
        public string YearEndDate
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("YearEndDate");
            }
        }

        /// <summary>
        /// Gets Resource Pool Daily Minimum Hours
        /// </summary>
        /// <returns></returns>
        public decimal RPDailyHours
        {
            get
            {
                return Convert.ToDecimal(ConfigurationManager.AppSettings.Get("RPDailyHours"));
            }
        }

        /// <summary>
        /// Gets Report Period
        /// </summary>
        public string ReportPeriod
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("ReportDuration");
            }
        }

        public string GivenDates
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("CustomDates");
            }
        }

        public string[] ProjectLevelApprovalList
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("ProjectLevelApprovalList").ToString().ToUpper().Split(',');
            }
        }      
       
        public int TimesheetStartWeekNo
        {
            get
            {
                return int.Parse(ConfigurationManager.AppSettings.Get("TimesheetStartWeekNo").ToString());
            }
        }

        public string HREmail
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("HREmail").ToString();
            }
        }

        public int IncludePastDataUtilizationYear
        {
            get
            {
                return int.Parse(ConfigurationManager.AppSettings.Get("IncludePastDataUtilizationYear").ToString());
            }
        }

        public string[] ExcludeCCWarningNC
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("ExcludeCCWarningNC").ToString().ToLowerInvariant().Split(',');
            }
        }
        /// <summary>
        /// Gets Week Start Day
        /// </summary>
        /// <returns>DayOfWeek enum</returns>
        public DayOfWeek WeekStartDay
        {
            get
            {
                return CultureInfo.CurrentCulture.DateTimeFormat.FirstDayOfWeek;
            }
        }

        /// <summary>
        /// Gets Week End Date
        /// </summary>
        /// <returns>DayOfWeek enum</returns>
        public DayOfWeek WeekEndDay
        {
            get
            {
                return Utility.Instance.WeekStartDay + 6;
            }
        }

        public int GetCurrentWeekNo()
        {
            return this.GetWeekNo(DateTime.Now);
        }

        public int GetLastWeekNo()
        {
            int weekNo = this.GetWeekNo(DateTime.Now);
            return (weekNo == 1 ? 52 : weekNo - 1);
        }

        /// <summary>
        /// To get the Week Number of a date
        /// </summary>
        /// <param name="date">date</param>
        /// <returns></returns>
        public int GetWeekNo(DateTime date)
        {
            return CultureInfo.CurrentCulture.Calendar.GetWeekOfYear(date, CalendarWeekRule.FirstFourDayWeek, this.WeekStartDay);
        }

        public string GetDateByWeekNo(int weekNo, int year)
        {
            return GetPreviousWeekWorkingDay(new DateTime(year, 1, 1).AddDays(7 * weekNo));
        }

        public DateTime GetDateDDMMYYYY(string dt)
        {
            return DateTime.ParseExact(dt, Constant.DATEDDMMYYYY, CultureInfo.InvariantCulture);
        }

        public string GetPreviousWeekWorkingDay(DateTime date)
        {
            return GetPreviousWeekDate(date).ToString(Constant.DDMMYYYY);
        }

        public string GetPreviousWeekWorkingDay()
        {
            return this.GetPreviousWeekWorkingDay(DateTime.Now);
        }

        public DateTime GetPreviousWeekDate(DateTime date)
        {
            double offSet = 0;
            switch (date.DayOfWeek)
            {
                case DayOfWeek.Saturday:
                    offSet = -1;
                    break;
                case DayOfWeek.Sunday:
                    offSet = -2;
                    break;
                case DayOfWeek.Monday:
                    offSet = -3;
                    break;
                case DayOfWeek.Tuesday:
                    offSet = -4;
                    break;
                case DayOfWeek.Wednesday:
                    offSet = -5;
                    break;
                case DayOfWeek.Thursday:
                    offSet = -6;
                    break;
                case DayOfWeek.Friday:
                    offSet = -7;
                    break;
            }

            return date.AddDays(offSet);
        }

        /// <summary>
        /// This method retuns first & last day of a week
        /// </summary>
        /// <param name="year">Year of week</param>
        /// <param name="weekNumber">Week number</param>
        /// <returns>First & last date of the week</returns>
        public Tuple<DateTime, DateTime> GetDatesOfWeek(int year, int weekNumber)
        {
            System.Globalization.Calendar calendar = CultureInfo.CurrentCulture.Calendar;
            weekNumber = weekNumber - 1;
            DateTime firstOfYear = new DateTime(year, 1, 1, calendar);
            DateTime targetStDay = calendar.AddWeeks(firstOfYear, weekNumber);
            DateTime targetEdDay = calendar.AddWeeks(firstOfYear, weekNumber);

            DayOfWeek dayOfWeek = CultureInfo.CurrentCulture.DateTimeFormat.FirstDayOfWeek;

            while (targetStDay.DayOfWeek != dayOfWeek)
            {
                targetStDay = targetStDay.AddDays(-1);
            }

            dayOfWeek = dayOfWeek + 6;
            while (targetEdDay.DayOfWeek != dayOfWeek)
            {
                targetEdDay = targetEdDay.AddDays(1);
            }

            return new Tuple<DateTime, DateTime>(targetStDay, targetEdDay);
        }

        public bool IsProjectAllowed(string pId)
        {
            return Utility.Instance.ProjectLevelApprovalList.Contains(pId.ToUpper());
        }

        /// <summary>
        /// This method returns startdate, enddate based on configuration. Referred keys in webconfig are ReportDuration, ReportDates.
        /// </summary>
        /// <returns>Start date, end date</returns>
        public Tuple<DateTime, DateTime> GetReportDuration(int startYear, bool isTillDate = false)
        {
            Tuple<DateTime, DateTime> result = null;
            int currentYear = CultureInfo.CurrentCulture.Calendar.GetYear(DateTime.Now);
            int currentMonth = CultureInfo.CurrentCulture.Calendar.GetMonth(DateTime.Now);
            ReportDuration reportPeriod = (ReportDuration)Enum.Parse(typeof(ReportDuration), this.ReportPeriod, true);

            switch (reportPeriod)
            {
                case ReportDuration.CurrentYear:
                    result = new Tuple<DateTime, DateTime>(new DateTime(currentYear, (int)Month.January, 01), new DateTime(currentYear, (int)Month.December, CultureInfo.CurrentCulture.Calendar.GetDaysInMonth(currentYear, (int)Month.December)));
                    break;
                case ReportDuration.FinancialYear:
                    if (startYear > 0)
                    {
                        result = new Tuple<DateTime, DateTime>(new DateTime(startYear, (int)Month.April, 01), new DateTime(startYear + 1, (int)Month.March, CultureInfo.CurrentCulture.Calendar.GetDaysInMonth(startYear + 1, (int)Month.March)));
                        break;
                    }
                    if (currentMonth > 3)
                    {
                        result = new Tuple<DateTime, DateTime>(new DateTime(currentYear, (int)Month.April, 01), new DateTime(currentYear + 1, (int)Month.March, CultureInfo.CurrentCulture.Calendar.GetDaysInMonth(currentYear + 1, (int)Month.March)));
                    }
                    else
                    {
                        result = new Tuple<DateTime, DateTime>(new DateTime(currentYear - 1, (int)Month.April, 01), new DateTime(currentYear, (int)Month.March, CultureInfo.CurrentCulture.Calendar.GetDaysInMonth(currentYear, (int)Month.March)));
                    }
                    break;
                case ReportDuration.CustomDates:
                    DateTime startDate = DateTime.Now, endDate = DateTime.Now;
                    if (!string.IsNullOrEmpty(this.GivenDates))
                    {
                        string[] dates = this.GivenDates.Split(new char[1] { ',' });

                        if (dates.Length > 0)
                        {
                            string[] dateArray = dates[0].Split(new char[1] { '/' });
                            startDate = new DateTime(Convert.ToInt32(dateArray[1]), Convert.ToInt32(dateArray[0]), 1);

                            dateArray = dates[1].Split(new char[1] { '/' });
                            int endYear = Convert.ToInt32(dateArray[1]);
                            int endMonth = Convert.ToInt32(dateArray[0]);
                            endDate = new DateTime(endYear, endMonth, DateTime.DaysInMonth(endYear, endMonth));
                        }

                        result = new Tuple<DateTime, DateTime>(startDate, endDate);
                    }

                    break;
            }

            if (result != null && isTillDate)
            {
                result = new Tuple<DateTime, DateTime>(result.Item1, DateTime.Today);
            }
            else
            {
                if (isTillDate)
                {
                    result = new Tuple<DateTime, DateTime>(new DateTime(currentYear, (int)Month.April, 01), DateTime.Today);
                }
                else
                {
                    if (startYear > 0)
                    {
                        result = new Tuple<DateTime, DateTime>(new DateTime(startYear, (int)Month.April, 01), new DateTime(startYear + 1, (int)Month.March, CultureInfo.CurrentCulture.Calendar.GetDaysInMonth(startYear + 1, (int)Month.March)));
                        return result;
                    }
                    if (currentMonth > 3)
                    {
                        result = new Tuple<DateTime, DateTime>(new DateTime(currentYear, (int)Month.April, 01), new DateTime(currentYear + 1, (int)Month.March, CultureInfo.CurrentCulture.Calendar.GetDaysInMonth(currentYear + 1, (int)Month.March)));
                    }
                    else
                    {
                        result = new Tuple<DateTime, DateTime>(new DateTime(currentYear - 1, (int)Month.April, 01), new DateTime(currentYear, (int)Month.March, CultureInfo.CurrentCulture.Calendar.GetDaysInMonth(currentYear, (int)Month.March)));
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// This generic method is used to convert predefined formated string to Dictionary collection
        /// </summary>
        /// <param name="param">Predefined formatted sting</param>
        /// <returns>Key value pair collection</returns>
        public Dictionary<string, string> ParamToDictionary(string param)
        {
            char itemSeparator = '§', keySeparator = '±';

            Dictionary<string, string> collection = new Dictionary<string, string>();
            if (!string.IsNullOrEmpty(param))
            {
                collection = param.Split(itemSeparator).Select(pair => pair.Split(keySeparator)).ToDictionary(key => key[0].Trim(), value => value[1].Trim());
            }

            return collection;
        }
    }
}
