﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace TimeSheetServer.Models
{
    public class PETTimeSheetConnection : DbContext
    {
        // You can add custom code to this file. Changes will not be overwritten.
        // 
        // If you want Entity Framework to drop and regenerate your database
        // automatically whenever you change your model schema, please use data migrations.
        // For more information refer to the documentation:
        // http://msdn.microsoft.com/en-us/data/jj591621.aspx
    
        public PETTimeSheetConnection() : base("name=PETTimeSheetConnection")
        {
        }

        public System.Data.Entity.DbSet<TimeSheetServer.Models.ADProfile> ADProfiles { get; set; }
        public System.Data.Entity.DbSet<TimeSheetServer.Models.UserProfile> UserProfiles { get; set; }
        public System.Data.Entity.DbSet<TimeSheetServer.Models.Project> Projects { get; set; }
        public System.Data.Entity.DbSet<TimeSheetServer.Models.ProjectApproval> ProjectApprovals { get; set; }
        public System.Data.Entity.DbSet<TimeSheetServer.Models.ProjectPersonAllocation> ProjectPersonAllocations { get; set; }
        public System.Data.Entity.DbSet<TimeSheetServer.Models.ProjectTimesheet> ProjectTimesheets { get; set; }
        public System.Data.Entity.DbSet<TimeSheetServer.Models.ResourceAllocationHistory> ResourceAllocationHistorys { get; set; }
        public System.Data.Entity.DbSet<TimeSheetServer.Models.Task> Tasks { get; set; }
        public System.Data.Entity.DbSet<TimeSheetServer.Models.TaskGroup> TaskGroups { get; set; }
        public System.Data.Entity.DbSet<TimeSheetServer.Models.TimeCard> TimeCards { get; set; }
        public System.Data.Entity.DbSet<TimeSheetServer.Models.TimesheetRole> TimesheetRoles { get; set; }
        public System.Data.Entity.DbSet<TimeSheetServer.Models.WeeklyTimesheet> WeeklyTimesheets { get; set; }
        public System.Data.Entity.DbSet<TimeSheetServer.Models.AuthorizedApprover> AuthorizedApprovers { get; set; }
        public System.Data.Entity.DbSet<TimeSheetServer.Models.AbacRoleAction> AbacRoleActions { get; set; }
        public System.Data.Entity.DbSet<TimeSheetServer.Models.Holiday> Holidays { get; set; }
        public System.Data.Entity.DbSet<TimeSheetServer.Models.OrganizationCategory> OrganizationCategories { get; set; }
        public System.Data.Entity.DbSet<TimeSheetServer.Models.PastUtilization> PastUtilizations { get; set; }

        public System.Data.Entity.DbSet<TimeSheetServer.Models.Client> Clients { get; set; }
    }
}
