﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TimeSheetServer.Models
{
    public class PPA
    {
        public string ProjectName { get; set; }
        public string MyStartDate { get; set; }
        public string MyEndDate { get; set; }
        public string ProjectStartDate { get; set; }
        public string ProjectEndDate { get; set; }
        //public string ProjectManager { get; set; }
        public string AllocationPercentage { get; set; }
        //public string StartDateFormat { get; set; }
        //public string EndDateFormat { get; set; }
    }
}