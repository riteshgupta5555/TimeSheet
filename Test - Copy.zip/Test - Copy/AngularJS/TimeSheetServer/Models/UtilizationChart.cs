﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TimeSheetServer.Models
{
    public class UtilizationChart
    {
        public List<TimesheetProvider.UtilizationGraph> UtilizationGraphData { get; set; }
        public List<TimesheetProvider.UtilizationMatrix> UtilizationMatrixData { get; set; }
    }

}